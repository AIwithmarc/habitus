window.PASAJES_BILINGUES = {
  es: [
    { contenido: "Porque donde esté tu tesoro, allí estará también tu corazón.", pasaje: "Mateo 6:21" },
    { contenido: "Busquen primeramente el reino de Dios y su justicia, y todas estas cosas les serán añadidas.", pasaje: "Mateo 6:33" },
    { contenido: "El mayor entre ustedes será su servidor.", pasaje: "Mateo 23:11" },
    { contenido: "Cuando ustedes digan 'sí', que sea realmente sí; y cuando digan 'no', que sea no.", pasaje: "Mateo 5:37" },
    { contenido: "De noche y de día, duerma o se levante, la semilla brota y crece sin que él sepa cómo.", pasaje: "Marcos 4:27" },
    { contenido: "Traten a los demás tal y como quieren que ellos los traten a ustedes.", pasaje: "Lucas 6:31" },
    { contenido: "Conocerán la verdad, y la verdad los hará libres.", pasaje: "Juan 8:32" },
    { contenido: "Confía en el Señor de todo corazón, y no te apoyes en tu propia prudencia. Reconócelo en todos tus caminos, y él allanará tus sendas.", pasaje: "Proverbios 3:5-6" },
    { contenido: "Tu palabra es una lámpara a mis pies; es una luz en mi sendero.", pasaje: "Salmo 119:105" },
    { contenido: "Tengan cuidado de su manera de vivir. No vivan como necios sino como sabios, aprovechando bien el tiempo.", pasaje: "Efesios 5:15-16" }
  ],
  en: [
    { contenido: "For where your treasure is, there your heart will be also.", pasaje: "Matthew 6:21" },
    { contenido: "But seek first his kingdom and his righteousness, and all these things will be given to you as well.", pasaje: "Matthew 6:33" },
    { contenido: "The greatest among you will be your servant.", pasaje: "Matthew 23:11" },
    { contenido: "All you need to say is simply 'Yes' or 'No'; anything beyond this comes from the evil one.", pasaje: "Matthew 5:37" },
    { contenido: "Night and day, whether he sleeps or gets up, the seed sprouts and grows, though he does not know how.", pasaje: "Mark 4:27" },
    { contenido: "Do to others as you would have them do to you.", pasaje: "Luke 6:31" },
    { contenido: "Then you will know the truth, and the truth will set you free.", pasaje: "John 8:32" },
    { contenido: "Trust in the Lord with all your heart and lean not on your own understanding; in all your ways submit to him, and he will make your paths straight.", pasaje: "Proverbs 3:5-6" },
    { contenido: "Your word is a lamp for my feet, a light on my path.", pasaje: "Psalm 119:105" },
    { contenido: "Be very careful, then, how you live—not as unwise but as wise, making the most of every opportunity.", pasaje: "Ephesians 5:15-16" }
  ]
}; 